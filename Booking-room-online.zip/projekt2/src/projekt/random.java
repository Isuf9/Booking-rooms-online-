package projekt;

import java.util.Random;

public class random {
    public static void main(String[] args) {
        Random r = new Random();
        for (int i=0;i<100;i++){
            int a = r.nextInt(100);
            System.out.println(a);
        }
    }
}
