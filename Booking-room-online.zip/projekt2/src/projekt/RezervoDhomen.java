package projekt;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.stage.Stage;

import java.io.FileInputStream;
import java.sql.*;
import java.util.Optional;

public class RezervoDhomen extends Application {

    public static void main(String[] args) {
        launch(args);
    }
    private Connection con;
    private Statement st;
    private ResultSet rs;

    String SQLserver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    String ConnectionURL =
            "jdbc:sqlserver://localhost:1433;" +
                    "databaseName=LendeLaboratorike;user=sa;password=arlind11;";

    public RezervoDhomen() {
        try{
            String connectionUrl = "jdbc:sqlserver://localhost:1433;" +
                    "databaseName=LendeLaboratorike;user=sa;password=arlind11;";
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            con = DriverManager.getConnection(connectionUrl);
            st = con.createStatement();
            System.out.println("Connected");
        }
        catch (Exception err)
        {
            System.err.println("Error loading JDBC driver");
            err.printStackTrace(System.err);
            System.exit(0);
        }
    }

    @Override
    public void start(Stage stage) {
        home home = new home();

        /*try
        {
            //Connect to the database
            Connection con = DriverManager.getConnection(ConnectionURL);
            System.out.println("Connected to the database");
            st = con.createStatement();

        }
        catch (Exception err)
        {
            System.err.println("Error connecting to the database");
            err.printStackTrace(System.err);
            System.exit(0);
        }*/

        ScrollPane scrollPane = new ScrollPane();
        GridPane g = new GridPane();
        g.setStyle("-fx-background-color:#363348;");
        scrollPane.setContent(g);
        Scene scene = new Scene(scrollPane,1400,800);
        g.setPrefHeight(scene.getHeight());
        double a = scene.getWidth();

        AnchorPane anchorPane = new AnchorPane();
        HBox hBox = new HBox();
        hBox.setPrefWidth(a);
        Label label = new Label("Rezervimet");
        HBox.setMargin(label,new Insets(5)); label.setId("label1");
        Label label2 = new Label("Stafi");
        HBox.setMargin(label2,new Insets(5));label2.setId("label1");
        AnchorPane.setTopAnchor(hBox,1.0);
        label.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                ListaRezervimeve listaRezervimeve = new ListaRezervimeve();
                listaRezervimeve.start(stage);
            }
        });
        label2.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                MenagjoStafin menagjoStafin = new MenagjoStafin();
                menagjoStafin.start(stage);
            }
        });
        hBox.setId("header");
        hBox.getChildren().addAll(label,label2);
//124 height    100 width
        HBox hBox1 = new HBox();hBox1.setId("choose");

        Pane pane = new Pane();
        pane.setPrefWidth(200);
        pane.setPrefHeight(100);
        HBox.setMargin(pane,new Insets(0,100,0,0));pane.setId("pane1");
        Label label4 = new Label("Rezervo Dhomen");label4.setId("whiteText");
//        Label label5 = new Label("Dhoma te Lira:");label5.setId("whiteText1");
//        Label label6 = new Label("102");label6.setId("whiteText1");
        VBox vBox  = new VBox();
        HBox hBox2 = new HBox();
//        hBox2.getChildren().addAll(label5,label6);
        vBox.getChildren().addAll(label4,hBox2);
        Pane pane4 = new Pane();pane4.setId("icon");

        pane4.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                RezervoDhomen rezervoDhomen = new RezervoDhomen();
                rezervoDhomen.start(stage);
            }
        });

        pane4.setStyle("-fx-background-color: #FF8058");
        pane4.setPrefHeight(42);
        pane4.setPrefWidth(42);
        pane4.setLayoutX(79);
        pane4.setLayoutY(-21);
        FileInputStream fileInputStream;
        Image image;
        ImageView imageView = new ImageView();
        try {
            fileInputStream = new FileInputStream("plus.png");
            image = new Image(fileInputStream);
            imageView = new ImageView(image);
        }catch (Exception e){
            e.printStackTrace();
        }
        pane4.getChildren().add(imageView);
        imageView.setX(12);
        imageView.setY(12);
        vBox.setLayoutX(25);
        vBox.setLayoutY(25);
        pane.getChildren().addAll(pane4,vBox);

        Pane pane1 = new Pane();
        pane1.setPrefWidth(200);
        pane1.setPrefHeight(100);
        HBox.setMargin(pane1,new Insets(0,100,0,0));pane1.setId("pane1");
        Label label7 = new Label("Lista Rezervimeve");label7.setId("whiteText");
//        Label label8 = new Label("Dhoma te Lira:");label8.setId("whiteText1");
//        Label label9 = new Label("102");label9.setId("whiteText1");
        VBox vBox1 = new VBox();
        HBox hBox3 = new HBox();
//        hBox3.getChildren().addAll(label8,label9);
        vBox1.getChildren().addAll(label7,hBox3);
        Pane pane5 = new Pane();pane5.setId("icon");
        pane5.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                ListaRezervimeve listaRezervimeve = new ListaRezervimeve();
                listaRezervimeve.start(stage);
            }
        });
        pane5.setPrefHeight(42);
        pane5.setPrefWidth(42);
        pane5.setLayoutX(79);
        pane5.setLayoutY(-21);
        FileInputStream fileInputStream1;
        Image image1;
        ImageView imageView1 = new ImageView();
        try {
            fileInputStream1 = new FileInputStream("1.png");
            image1 = new Image(fileInputStream1);
            imageView1 = new ImageView(image1);
        }catch (Exception e){
            e.printStackTrace();
        }
        pane5.getChildren().add(imageView1);
        imageView1.setFitWidth(15);
        imageView1.setFitHeight(13);
        imageView1.setX(14.5);
        imageView1.setY(15.5);
        vBox1.setLayoutX(25);
        vBox1.setLayoutY(25);
        pane1.getChildren().addAll(pane5,vBox1);

        Pane pane2 = new Pane();
        pane2.setPrefWidth(200);
        pane2.setPrefHeight(100);
        HBox.setMargin(pane2,new Insets(0,100,0,0));pane2.setId("pane1");
        Label label10 = new Label("Stafi Menagjues");label10.setId("whiteText");
//        Label label11 = new Label("Dhoma te Lira:");label11.setId("whiteText1");
//        Label label12 = new Label("102");label12.setId("whiteText1");
        VBox vBox2 = new VBox();
        HBox hBox4 = new HBox();
//        hBox4.getChildren().addAll(label11,label12);
        vBox2.getChildren().addAll(label10,hBox4);
        Pane pane6 = new Pane();pane6.setId("icon");
        pane6.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                MenagjoStafin menagjoStafin = new MenagjoStafin();
                menagjoStafin.start(stage);
            }
        });
        pane6.setPrefHeight(42);
        pane6.setPrefWidth(42);
        pane6.setLayoutX(79);
        pane6.setLayoutY(-21);

        FileInputStream fileInputStream2;
        Image image2;
        ImageView imageView2 = new ImageView();
        try {
            fileInputStream2 = new FileInputStream("22.png");
            image2 = new Image(fileInputStream2);
            imageView2 = new ImageView(image2);
        }catch (Exception e){
            e.printStackTrace();
        }
        pane6.getChildren().add(imageView2);
        imageView2.setX(10);
        imageView2.setY(10);

        vBox2.setLayoutX(25);
        vBox2.setLayoutY(25);
        pane2.getChildren().addAll(pane6,vBox2);

        Pane pane3 = new Pane();
        pane3.setPrefWidth(200);
        pane3.setPrefHeight(100);
        Label label13 = new Label("Menagjo te Dhenat");label13.setId("whiteText");
//        Label label14 = new Label("Dhoma te Lira:");label14.setId("whiteText1");
//        Label label15 = new Label("102");label15.setId("whiteText1");
        VBox vBox3 = new VBox();
        HBox hBox5 = new HBox();
//        hBox5.getChildren().addAll(label14,label15);
        vBox3.getChildren().addAll(label13,hBox5);
        Pane pane7 = new Pane();pane7.setId("icon");
        pane7.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                MenagjoDhenat menagjoDhenat = new MenagjoDhenat();
                menagjoDhenat.start(stage);
            }
        });
        pane7.setPrefHeight(42);
        pane7.setPrefWidth(42);
        pane7.setLayoutX(79);
        pane7.setLayoutY(-21);

        FileInputStream fileInputStream3;
        Image image3;
        ImageView imageView3 = new ImageView();
        try {
            fileInputStream3 = new FileInputStream("33.png");
            image3 = new Image(fileInputStream3);
            imageView3 = new ImageView(image3);
        }catch (Exception e){
            e.printStackTrace();
        }
        pane7.getChildren().add(imageView3);
        imageView3.setX(12);
        imageView3.setY(11);

        vBox3.setLayoutX(25);
        vBox3.setLayoutY(25);
        pane3.getChildren().addAll(pane7,vBox3);pane3.setId("pane1");

        hBox1.getChildren().addAll(pane,pane1,pane2,pane3);

        AnchorPane.setTopAnchor(hBox1,140.0);
        AnchorPane.setLeftAnchor(hBox1,100.0);

        //ketu mbaron pjesa e pare

        VBox vBox4 = new VBox();vBox4.setId("pane1");
        AnchorPane.setLeftAnchor(vBox4,100.0);
        AnchorPane.setTopAnchor(vBox4,300.0);
        vBox4.setPrefSize(1100,350);
        Label label16 = new Label("Forme e Rezervimit");
        label16.setId("label16");
        Line line = new Line();line.setId("line");
        line.setStrokeWidth(2);
        line.setStroke(Color.rgb(85,73,100));
        line.setStartX(170);
        line.setStartY(130);
        line.setEndX(1220);
        line.setEndY(130);
        VBox.setMargin(line,new Insets(0,0,0,20));

        HBox hBox6 = new HBox();
        hBox6.setPadding(new Insets(0,5,0,5));
        Label label17 = new Label("Emri");label17.setId("data");
        TextField Emri = new TextField();
        Emri.setPromptText("Emri");
        VBox.setMargin(Emri,new Insets(0,10,0,10));
        VBox v1 = new VBox();
        v1.getChildren().addAll(label17,Emri);
        Label label18 = new Label("Mbiemri");label18.setId("data");
        TextField Mbiemri = new TextField();
        Mbiemri.setPromptText("Mbiemri");
        VBox.setMargin(Mbiemri,new Insets(0,10,0,10));
        VBox v2 = new VBox();
        v2.getChildren().addAll(label18,Mbiemri);
        Label label19 = new Label("Qyteti");label19.setId("data");
        TextField Qyteti = new TextField();
        Qyteti.setPromptText("Qyteti");
        VBox.setMargin(Qyteti,new Insets(0,10,0,10));
        VBox v3 = new VBox();
        v3.getChildren().addAll(label19,Qyteti);
        Label label1 = new Label("Shteti");label1.setId("data");
        TextField Shteti = new TextField();
        Shteti.setPromptText("Shteti");
        VBox.setMargin(Shteti,new Insets(0,10,0,10));
        VBox v4 = new VBox();
        v4.getChildren().addAll(label1,Shteti);
        hBox6.getChildren().addAll(v1,v2,v3,v4);
//pjesa e pare me text filda

        HBox hBox7 = new HBox();
        hBox7.setPadding(new Insets(-20,0,0,13));
        Label label20 = new Label("Mengjesi");label20.setId("data");
        TextField Mengjesi = new TextField();
        Mengjesi.setPromptText("Mengjesi");
        Mengjesi.setStyle("-fx-padding: 10px 54px 10px 5px;");
        VBox v11 = new VBox();
        VBox.setMargin(Mengjesi,new Insets(0,10,0,0));
        v11.getChildren().addAll(label20,Mengjesi);
        Label label21 = new Label("Data Rezervimit");label21.setId("data");
        label21.setStyle("-fx-padding: 10px 15px 10px 10px;");
        TextField Data_R = new TextField();
        Data_R.setPromptText("Data e Rezervimit");
        Data_R.setStyle("-fx-padding: 10px 50px 10px 5px;");
        VBox v12 = new VBox();
        VBox.setMargin(Data_R,new Insets(0,10,0,10));
        v12.getChildren().addAll(label21,Data_R);
        Label label22 = new Label("Data Skadimit");label22.setId("data");
        label22.setStyle("-fx-padding: 10 15 10 10");
        TextField Data_S = new TextField();
        Data_S.setPromptText("Data e Skadimit");
        Data_S.setStyle("-fx-padding: 10px 50px 10px 5px;");
        VBox v13 = new VBox();
        VBox.setMargin(Data_S,new Insets(0,10,0,10));
        v13.getChildren().addAll(label22,Data_S);
        Label label24 = new Label("Dhoma");label24.setId("data");
        label22.setStyle("-fx-padding: 10 15 10 10");
        TextField Dhoma = new TextField();
        Dhoma.setPromptText("Dhoma");
        Dhoma.setStyle("-fx-padding: 10px 50px 10px 5px;");
        VBox v14 = new VBox();
        VBox.setMargin(Dhoma,new Insets(0,10,0,10));
        v14.getChildren().addAll(label24,Dhoma);
        hBox7.getChildren().addAll(v11,v12,v13,v14);
//pjesa e dyte me texfillda

        VBox vBox5 = new VBox();
        VBox.setMargin(hBox6,new Insets(20));
        VBox.setMargin(hBox7,new Insets(20));
        vBox5.getChildren().addAll(hBox6,hBox7);

        Button button = new Button("Rezervo");
        button.setStyle("" +
                "-fx-background-color: #5A37AB;" +
                "-fx-padding: 10 50;" +
                "-fx-text-fill: #E2D4F2;" +
                "-fx-font-size: 14;" +
                "-fx-cursor: hand");

        button.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setHeaderText("A deshironi te beni Rezervimin");
                ButtonType buttonType = new ButtonType("OK");
                ButtonType buttonType1 = new ButtonType("Cancel");
                if (Emri.getText().isEmpty()) {
                    paralajmrim("Emri");
                } else if (Mbiemri.getText().isEmpty()) {
                    paralajmrim("Mbiemri");
                } else if (Qyteti.getText().isEmpty()) {
                    paralajmrim("Qyteti");
                } else if (Shteti.getText().isEmpty()) {
                    paralajmrim("Shteti");
                } else if (Mengjesi.getText().isEmpty()) {
                    paralajmrim("Mengjesi");
                } else if (Data_R.getText().isEmpty()) {
                    paralajmrim("Data e Rezervimit");
                } else if (Data_S.getText().isEmpty()) {
                    paralajmrim("Data e Skadimit");
                } else if (Dhoma.getText().isEmpty()) {
                    paralajmrim("Dhoma");
                }
                else {
                    Optional<ButtonType> res = alert.showAndWait();
                    if (res.get() == ButtonType.OK) {
                        try {
                            String SQL = "INSERT INTO Home(Emri,Mbiemri,Qyteti,Shteti,Mengjesi,Data_R,Data_S,Dhoma) " +
                                    "VALUES (?,?,?,?,?,?,?,?)";
                            PreparedStatement ps = con.prepareStatement(SQL);
                            ps.setString(1, Emri.getText());
                            ps.setString(2, Mbiemri.getText());
                            ps.setString(3, Qyteti.getText());
                            ps.setString(4, Shteti.getText());
                            ps.setString(5, Mengjesi.getText());
                            ps.setString(6, Data_R.getText());
                            ps.setString(7, Data_S.getText());
                            ps.setString(8, Dhoma.getText());
                            ps.executeUpdate();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
                        alert1.setHeaderText("Rezervimi perfundoj me sukses");
                        alert1.show();
                    } else if (res.get() == ButtonType.CANCEL) {
                        Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
                        alert1.setHeaderText("Te dhenat per rezervim u anuluan");
                        alert1.show();
                    }
                }
            }
        });
        VBox.setMargin(button,new Insets(0,0,0,30));

        vBox4.getChildren().addAll(label16,line,vBox5,button);

        Label label23 = new Label("Kthehu tek faqja kryesore");
        label23.getStyleClass().add("kthehu");
        label23.setStyle("-fx-text-fill: #86739B;");
        label23.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                home.start(stage);
            }
        });
        AnchorPane.setTopAnchor(label23,650.0);
        AnchorPane.setLeftAnchor(label23,100.0);
        VBox.setMargin(label23,new Insets(40,0,0,100));

        anchorPane.getChildren().addAll(hBox,hBox1,vBox4,label23);
        g.getChildren().add(anchorPane);
        scene.getStylesheets().add("style2.css");
        stage.setTitle("Rezervo Dhomen");
        stage.setScene(scene);
        stage.show();
    }
    void paralajmrim(String perQka){
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setHeaderText(perQka+" nuk mund te jete i zbrazet");
        alert.show();
    }
}