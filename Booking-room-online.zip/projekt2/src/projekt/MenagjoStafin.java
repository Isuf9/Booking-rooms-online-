package projekt;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class MenagjoStafin extends Application {

    public static void main(String[] args) {
        launch(args);
    }
    private Connection con;
    private Statement st;
    private ResultSet rs;

    String SQLserver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    String ConnectionURL =
            "jdbc:sqlserver://localhost:1433;" +
                    "databaseName=LendeLaboratorike;user=sa;password=arlind11;";

    public MenagjoStafin() {
        try{
            String connectionUrl = "jdbc:sqlserver://localhost:1433;" +
                    "databaseName=LendeLaboratorike;user=sa;password=arlind11;";
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            con = DriverManager.getConnection(connectionUrl);
            st = con.createStatement();
            System.out.println("Connected");
        }
        catch (Exception err)
        {
            System.err.println("Error loading JDBC driver");
            err.printStackTrace(System.err);
            System.exit(0);
        }
    }

    ObservableList<ListaStafi> data = FXCollections.observableArrayList();

    @Override
    public void start(Stage stage) {
        home home = new home();

        try
        {
            //Connect to the database
            Connection con = DriverManager.getConnection(ConnectionURL);
            System.out.println("Connected to the database");
            st = con.createStatement();

            String queryString="select * from Table1";

            rs=st.executeQuery(queryString);
            while(rs.next()){
                System.out.print(rs.getString("ID"));
                System.out.println(rs.getString("Name"));
            }

        }
        catch (Exception err)
        {
            System.err.println("Error connecting to the database");
            err.printStackTrace(System.err);
            System.exit(0);
        }

        ScrollPane scrollPane = new ScrollPane();
        GridPane g = new GridPane();
        g.setStyle("-fx-background-color:#363348;");
        scrollPane.setContent(g);
        Scene scene = new Scene(scrollPane,1400,800);
        g.setPrefHeight(scene.getHeight());
        double a = scene.getWidth();

        AnchorPane anchorPane = new AnchorPane();
        HBox hBox = new HBox();
        hBox.setPrefWidth(a);
        Label label = new Label("Rezervimet");
        HBox.setMargin(label,new Insets(5)); label.setId("label1");
        Label label2 = new Label("Stafi");
        HBox.setMargin(label2,new Insets(5));label2.setId("label1");
        AnchorPane.setTopAnchor(hBox,1.0);
        label.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                ListaRezervimeve listaRezervimeve = new ListaRezervimeve();
                listaRezervimeve.start(stage);
            }
        });
        label2.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                MenagjoStafin menagjoStafin = new MenagjoStafin();
                menagjoStafin.start(stage);
            }
        });
        hBox.setId("header");
        hBox.getChildren().addAll(label,label2);
//124 height    100 width
        HBox hBox1 = new HBox();hBox1.setId("choose");

        Pane pane = new Pane();
        pane.setPrefWidth(200);
        pane.setPrefHeight(100);
        HBox.setMargin(pane,new Insets(0,100,0,0));pane.setId("pane1");
        Label label4 = new Label("Rezervo Dhomen");label4.setId("whiteText");
        /*Label label5 = new Label("Dhoma te Lira:");label5.setId("whiteText1");
        Label label6 = new Label("102");label6.setId("whiteText1");*/
        VBox vBox  = new VBox();
        HBox hBox2 = new HBox();
//        hBox2.getChildren().addAll(label5,label6);
        vBox.getChildren().addAll(label4,hBox2);
        Pane pane4 = new Pane();pane4.setId("icon");
        pane4.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                RezervoDhomen rezervoDhomen = new RezervoDhomen();
                rezervoDhomen.start(stage);
            }
        });
        pane4.setPrefHeight(42);
        pane4.setPrefWidth(42);
        pane4.setLayoutX(79);
        pane4.setLayoutY(-21);
        FileInputStream fileInputStream;
        Image image;
        ImageView imageView = new ImageView();
        try {
            fileInputStream = new FileInputStream("plus.png");
            image = new Image(fileInputStream);
            imageView = new ImageView(image);
        }catch (Exception e){
            e.printStackTrace();
        }
        pane4.getChildren().add(imageView);
        imageView.setX(12);
        imageView.setY(12);
        pane4.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                RezervoDhomen rezervoDhomen = new RezervoDhomen();
                rezervoDhomen.start(stage);
            }
        });
        vBox.setLayoutX(25);
        vBox.setLayoutY(25);
        pane.getChildren().addAll(pane4,vBox);

        Pane pane1 = new Pane();
        pane1.setPrefWidth(200);
        pane1.setPrefHeight(100);
        HBox.setMargin(pane1,new Insets(0,100,0,0));pane1.setId("pane1");
        Label label7 = new Label("Lista Rezervimeve");label7.setId("whiteText");
        /*Label label8 = new Label("Dhoma te Lira:");label8.setId("whiteText1");
        Label label9 = new Label("102");label9.setId("whiteText1");*/
        VBox vBox1 = new VBox();
        HBox hBox3 = new HBox();
//        hBox3.getChildren().addAll(label8,label9);
        vBox1.getChildren().addAll(label7,hBox3);
        Pane pane5 = new Pane();pane5.setId("icon");
        pane5.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                ListaRezervimeve listaRezervimeve = new ListaRezervimeve();
                listaRezervimeve.start(stage);
            }
        });
        pane5.setPrefHeight(42);
        pane5.setPrefWidth(42);
        pane5.setLayoutX(79);
        pane5.setLayoutY(-21);
        FileInputStream fileInputStream1;
        Image image1;
        ImageView imageView1 = new ImageView();
        try {
            fileInputStream1 = new FileInputStream("1.png");
            image1 = new Image(fileInputStream1);
            imageView1 = new ImageView(image1);
        }catch (Exception e){
            e.printStackTrace();
        }
        pane5.getChildren().add(imageView1);
        pane5.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                ListaRezervimeve listaRezervimeve = new ListaRezervimeve();
                listaRezervimeve.start(stage);
            }
        });
        imageView1.setFitWidth(15);
        imageView1.setFitHeight(13);
        imageView1.setX(14.5);
        imageView1.setY(15.5);
        vBox1.setLayoutX(25);
        vBox1.setLayoutY(25);
        pane1.getChildren().addAll(pane5,vBox1);

        Pane pane2 = new Pane();
        pane2.setPrefWidth(200);
        pane2.setPrefHeight(100);
        HBox.setMargin(pane2,new Insets(0,100,0,0));pane2.setId("pane1");
        Label label10 = new Label("Stafi Menagjues");label10.setId("whiteText");
        /*Label label11 = new Label("Dhoma te Lira:");label11.setId("whiteText1");
        Label label12 = new Label("102");label12.setId("whiteText1");*/
        VBox vBox2 = new VBox();
        HBox hBox4 = new HBox();
//        hBox4.getChildren().addAll(label11,label12);
        vBox2.getChildren().addAll(label10,hBox4);
        Pane pane6 = new Pane();pane6.setId("icon");
        pane6.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                MenagjoStafin menagjoStafin = new MenagjoStafin();
                menagjoStafin.start(stage);
            }
        });
        pane6.setPrefHeight(42);
        pane6.setPrefWidth(42);
        pane6.setLayoutX(79);
        pane6.setLayoutY(-21);
        pane6.setStyle("-fx-background-color: #FF8058");
        FileInputStream fileInputStream2;
        Image image2;
        ImageView imageView2 = new ImageView();
        try {
            fileInputStream2 = new FileInputStream("22.png");
            image2 = new Image(fileInputStream2);
            imageView2 = new ImageView(image2);
        }catch (Exception e){
            e.printStackTrace();
        }
        pane6.getChildren().add(imageView2);
        pane6.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {

            }
        });
        imageView2.setX(10);
        imageView2.setY(10);
        vBox2.setLayoutX(25);
        vBox2.setLayoutY(25);
        pane2.getChildren().addAll(pane6,vBox2);

        Pane pane3 = new Pane();
        pane3.setPrefWidth(200);
        pane3.setPrefHeight(100);
        Label label13 = new Label("Menagjo te Dhenat");label13.setId("whiteText");
        /*Label label14 = new Label("Dhoma te Lira:");label14.setId("whiteText1");
        Label label15 = new Label("102");label15.setId("whiteText1");*/
        VBox vBox3 = new VBox();
        HBox hBox5 = new HBox();
//        hBox5.getChildren().addAll(label14,label15);
        vBox3.getChildren().addAll(label13,hBox5);
        Pane pane7 = new Pane();pane7.setId("icon");
        pane7.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                MenagjoDhenat menagjoDhenat = new MenagjoDhenat();
                menagjoDhenat.start(stage);
            }
        });
        pane7.setPrefHeight(42);
        pane7.setPrefWidth(42);
        pane7.setLayoutX(79);
        pane7.setLayoutY(-21);

        FileInputStream fileInputStream3;
        Image image3;
        ImageView imageView3 = new ImageView();
        try {
            fileInputStream3 = new FileInputStream("33.png");
            image3 = new Image(fileInputStream3);
            imageView3 = new ImageView(image3);
        }catch (Exception e){
            e.printStackTrace();
        }
        pane7.getChildren().add(imageView3);
        pane7.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                MenagjoDhenat menagjoDhenat = new MenagjoDhenat();
                menagjoDhenat.start(stage);
            }
        });
        imageView3.setX(12);
        imageView3.setY(11);

        vBox3.setLayoutX(25);
        vBox3.setLayoutY(25);
        pane3.getChildren().addAll(pane7,vBox3);pane3.setId("pane1");

        hBox1.getChildren().addAll(pane,pane1,pane2,pane3);

        VBox vBox4 = new VBox(); vBox4.setId("pane8");
        vBox4.setPrefWidth(1100);
        vBox4.setPrefHeight(300);
        vBox4.setLayoutY(300);
        vBox4.setLayoutX(100);
        Label label16 = new Label("Rezervimet e fundit");label16.setId("label16");
        label16.setFont(Font.font(18));
        label16.setPadding(new Insets(20));

        TableView<ListaStafi> tableView = new TableView<ListaStafi>();
        tableView.setId("tableView");
        tableView.setPrefHeight(300);
        Label tableViewPlaceHolder = new Label("Nuk ka rezervime te reja");
        tableViewPlaceHolder.setStyle("-fx-text-fill:#302D40;");
        tableView.setPlaceholder(tableViewPlaceHolder);

        data = FXCollections.observableArrayList();

        TableColumn EmriCol = new TableColumn("Emri");
        EmriCol.setPrefWidth(170);
        TableColumn mbiemriCol = new TableColumn("Mbiemri");
        mbiemriCol.setPrefWidth(180);
        TableColumn qytetiCol = new TableColumn("Qyteti");
        qytetiCol.setPrefWidth(180);
        TableColumn Rolicol = new TableColumn("Roli");
        Rolicol.setPrefWidth(168);
        TableColumn FillimiPunes = new TableColumn("Fillimi Punes");
        FillimiPunes.setPrefWidth(180);
        TableColumn PagaMujore = new TableColumn("Paga Mujore");
        PagaMujore.setPrefWidth(180);

        EmriCol.setCellValueFactory(
                new PropertyValueFactory<ListaStafi, String>("emrii"));
        mbiemriCol.setCellValueFactory(
                new PropertyValueFactory<ListaStafi, String>("mbiemrii"));
        qytetiCol.setCellValueFactory(
                new PropertyValueFactory<ListaStafi, String>("qytetii"));
        Rolicol.setCellValueFactory(
                new PropertyValueFactory<ListaStafi, String>("roli"));
        FillimiPunes.setCellValueFactory(
                new PropertyValueFactory<ListaStafi, String>("fillimiPunes"));
        PagaMujore.setCellValueFactory(
                new PropertyValueFactory<ListaStafi, String>("pagaMujore"));
        try{
            String SQL = "Select * from MenagjoStafin";
            ResultSet rs = con.createStatement().executeQuery(SQL);
            while(rs.next()){
                ListaStafi cm = new ListaStafi();
                cm.emrii.set(rs.getString("Emri"));
                cm.mbiemrii.set(rs.getString("Mbiemri"));
                cm.qytetii.set(rs.getString("Qyteti"));
                cm.roli.set(rs.getString("Roli"));
                cm.fillimiPunes.set(rs.getString("FillimiPunes"));
                cm.pagaMujore.set(rs.getString("PagaMujore"));
                data.add(cm);
            }
            tableView.setItems(data);
        }
        catch(Exception e){
            e.printStackTrace();
            System.out.println("Error te dhenat nuk jane paraqitur");
        }

        tableView.getColumns().addAll(EmriCol,mbiemriCol,qytetiCol,Rolicol,FillimiPunes,PagaMujore);
        VBox.setMargin(tableView,new Insets(0,20,0,20));

        vBox4.getChildren().addAll(label16,tableView);

        AnchorPane.setTopAnchor(hBox1,140.0);

        AnchorPane.setLeftAnchor(hBox1,100.0);
        Label label23 = new Label("Kthehu tek faqja kryesore");
        label23.getStyleClass().addAll("kthehu");
        label23.setStyle("-fx-text-fill: #86739B;");
        label23.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                home.start(stage);
            }
        });
        AnchorPane.setTopAnchor(label23,650.0);
        AnchorPane.setLeftAnchor(label23,100.0);
        VBox.setMargin(label23,new Insets(20,0,0,100));

        anchorPane.getChildren().addAll(hBox,hBox1,vBox4,label23);
        g.getChildren().add(anchorPane);
        scene.getStylesheets().addAll("style.css","style4.css");
        stage.setTitle("Menagjo Stafin");
        stage.setScene(scene);
        stage.show();
    }
}
