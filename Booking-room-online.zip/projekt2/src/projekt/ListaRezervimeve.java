package projekt;

import javafx.application.Application;
import javafx.beans.binding.Bindings;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.print.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.transform.Scale;
import javafx.scene.transform.Translate;
import javafx.stage.Stage;

import java.io.FileInputStream;
import java.sql.*;
import java.util.Optional;

public class ListaRezervimeve extends Application {

    public static void main(String[] args) {
        launch(args);
    }
    private Connection con;
    private Statement st;
    private ResultSet rs;

    String SQLserver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    String ConnectionURL =
            "jdbc:sqlserver://localhost:1433;" +
                    "databaseName=LendeLaboratorike;user=sa;password=arlind11;";

    public ListaRezervimeve() {
        try{
            String connectionUrl = "jdbc:sqlserver://localhost:1433;" +
                    "databaseName=LendeLaboratorike;user=sa;password=arlind11;";
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            con = DriverManager.getConnection(connectionUrl);
            st = con.createStatement();
            System.out.println("Connected");
        }
        catch (Exception err)
        {
            System.err.println("Error loading JDBC driver");
            err.printStackTrace(System.err);
            System.exit(0);
        }
    }

    ObservableList<Lista> data = FXCollections.observableArrayList();

    @Override
    public void start(Stage stage) {
        home home = new home();

        try
        {
            //Connect to the database
            Connection con = DriverManager.getConnection(ConnectionURL);
            System.out.println("Connected to the database");
            st = con.createStatement();

            String queryString="select * from Table1";

            rs=st.executeQuery(queryString);
            while(rs.next()){
                System.out.print(rs.getString("ID"));
                System.out.println(rs.getString("Name"));
            }

        }
        catch (Exception err)
        {
            System.err.println("Error connecting to the database");
            err.printStackTrace(System.err);
            System.exit(0);
        }

        ScrollPane scrollPane = new ScrollPane();
        GridPane g = new GridPane();
        g.setStyle("-fx-background-color:#363348;");
        scrollPane.setContent(g);
        Scene scene = new Scene(scrollPane,1400,800);
        g.setPrefHeight(scene.getHeight());
        double a = scene.getWidth();

        AnchorPane anchorPane = new AnchorPane();
        HBox hBox = new HBox();
        hBox.setPrefWidth(a);
        Label label = new Label("Rezervimet");
        HBox.setMargin(label,new Insets(5)); label.setId("label1");
        Label label2 = new Label("Stafi");
        HBox.setMargin(label2,new Insets(5));label2.setId("label1");
        label.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                ListaRezervimeve listaRezervimeve = new ListaRezervimeve();
                listaRezervimeve.start(stage);
            }
        });
        label2.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                MenagjoStafin menagjoStafin = new MenagjoStafin();
                menagjoStafin.start(stage);
            }
        });
        AnchorPane.setTopAnchor(hBox,1.0);
        hBox.setId("header");
        hBox.getChildren().addAll(label,label2);
//124 height    100 width
        HBox hBox1 = new HBox();hBox1.setId("choose");

        Pane pane = new Pane();
        pane.setPrefWidth(200);
        pane.setPrefHeight(100);
        HBox.setMargin(pane,new Insets(0,100,0,0));pane.setId("pane1");
        Label label4 = new Label("Rezervo Dhomen");label4.setId("whiteText");
//        Label label5 = new Label("Dhoma te Lira:");label5.setId("whiteText1");
//        Label label6 = new Label("102");label6.setId("whiteText1");
        VBox vBox  = new VBox();
        HBox hBox2 = new HBox();
//        hBox2.getChildren().addAll(label5,label6);
        vBox.getChildren().addAll(label4,hBox2);
        Pane pane4 = new Pane();pane4.setId("icon");
        pane4.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                RezervoDhomen rezervoDhomen = new RezervoDhomen();
                rezervoDhomen.start(stage);
            }
        });
        pane4.setPrefHeight(42);
        pane4.setPrefWidth(42);
        pane4.setLayoutX(79);
        pane4.setLayoutY(-21);
        FileInputStream fileInputStream;
        Image image;
        ImageView imageView = new ImageView();
        try {
            fileInputStream = new FileInputStream("plus.png");
            image = new Image(fileInputStream);
            imageView = new ImageView(image);
        }catch (Exception e){
            e.printStackTrace();
        }
        pane4.getChildren().add(imageView);
        imageView.setX(12);
        imageView.setY(12);
        pane4.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                RezervoDhomen rezervoDhomen = new RezervoDhomen();
                rezervoDhomen.start(stage);
            }
        });
        vBox.setLayoutX(25);
        vBox.setLayoutY(25);
        pane.getChildren().addAll(pane4,vBox);

        Pane pane1 = new Pane();
        pane1.setPrefWidth(200);
        pane1.setPrefHeight(100);
        HBox.setMargin(pane1,new Insets(0,100,0,0));pane1.setId("pane1");
        Label label7 = new Label("Lista Rezervimeve");label7.setId("whiteText");
//        Label label8 = new Label("Dhoma te Lira:");label8.setId("whiteText1");
//        Label label9 = new Label("102");label9.setId("whiteText1");
        VBox vBox1 = new VBox();
        HBox hBox3 = new HBox();
//        hBox3.getChildren().addAll(label8,label9);
        vBox1.getChildren().addAll(label7,hBox3);
        Pane pane5 = new Pane();pane5.setId("icon");
        pane5.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                ListaRezervimeve listaRezervimeve = new ListaRezervimeve();
                listaRezervimeve.start(stage);
            }
        });
        pane5.setPrefHeight(42);
        pane5.setPrefWidth(42);
        pane5.setLayoutX(79);
        pane5.setLayoutY(-21);
        pane5.setStyle("-fx-background-color: #FF8058");
        FileInputStream fileInputStream1;
        Image image1;
        ImageView imageView1 = new ImageView();
        try {
            fileInputStream1 = new FileInputStream("1.png");
            image1 = new Image(fileInputStream1);
            imageView1 = new ImageView(image1);
        }catch (Exception e){
            e.printStackTrace();
        }
        pane5.getChildren().add(imageView1);
        pane5.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                RezervoDhomen rezervoDhomen = new RezervoDhomen();
                rezervoDhomen.start(stage);
            }
        });
        imageView1.setFitWidth(15);
        imageView1.setFitHeight(13);
        imageView1.setX(14.5);
        imageView1.setY(15.5);
        vBox1.setLayoutX(25);
        vBox1.setLayoutY(25);
        pane1.getChildren().addAll(pane5,vBox1);

        Pane pane2 = new Pane();
        pane2.setPrefWidth(200);
        pane2.setPrefHeight(100);
        HBox.setMargin(pane2,new Insets(0,100,0,0));pane2.setId("pane1");
        Label label10 = new Label("Stafi Menagjues");label10.setId("whiteText");
//        Label label11 = new Label("Dhoma te Lira:");label11.setId("whiteText1");
//        Label label12 = new Label("102");label12.setId("whiteText1");
        VBox vBox2 = new VBox();
        HBox hBox4 = new HBox();
//        hBox4.getChildren().addAll(label11,label12);
        vBox2.getChildren().addAll(label10,hBox4);
        Pane pane6 = new Pane();pane6.setId("icon");
        pane6.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                MenagjoStafin menagjoStafin = new MenagjoStafin();
                menagjoStafin.start(stage);
            }
        });
        pane6.setPrefHeight(42);
        pane6.setPrefWidth(42);
        pane6.setLayoutX(79);
        pane6.setLayoutY(-21);

        FileInputStream fileInputStream2;
        Image image2;
        ImageView imageView2 = new ImageView();
        try {
            fileInputStream2 = new FileInputStream("22.png");
            image2 = new Image(fileInputStream2);
            imageView2 = new ImageView(image2);
        }catch (Exception e){
            e.printStackTrace();
        }
        pane6.getChildren().add(imageView2);
        imageView2.setX(10);
        imageView2.setY(10);

        vBox2.setLayoutX(25);
        vBox2.setLayoutY(25);
        pane2.getChildren().addAll(pane6,vBox2);

        Pane pane3 = new Pane();
        pane3.setPrefWidth(200);
        pane3.setPrefHeight(100);
        Label label13 = new Label("Menagjo te Dhenat");label13.setId("whiteText");
        VBox vBox3 = new VBox();
        HBox hBox5 = new HBox();
        vBox3.getChildren().addAll(label13,hBox5);
        Pane pane7 = new Pane();pane7.setId("icon");
        pane7.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                MenagjoDhenat menagjoDhenat = new MenagjoDhenat();
                menagjoDhenat.start(stage);
            }
        });
        pane7.setPrefHeight(42);
        pane7.setPrefWidth(42);
        pane7.setLayoutX(79);
        pane7.setLayoutY(-21);

        FileInputStream fileInputStream3;
        Image image3;
        ImageView imageView3 = new ImageView();
        try {
            fileInputStream3 = new FileInputStream("33.png");
            image3 = new Image(fileInputStream3);
            imageView3 = new ImageView(image3);
        }catch (Exception e){
            e.printStackTrace();
        }
        pane7.getChildren().add(imageView3);
        pane7.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                MenagjoDhenat menagjoDhenat = new MenagjoDhenat();
                menagjoDhenat.start(stage);
            }
        });
        imageView3.setX(12);
        imageView3.setY(11);

        vBox3.setLayoutX(25);
        vBox3.setLayoutY(25);
        pane3.getChildren().addAll(pane7,vBox3);pane3.setId("pane1");

        hBox1.getChildren().addAll(pane,pane1,pane2,pane3);

        VBox vBox4 = new VBox(); vBox4.setId("pane8");
        vBox4.setPrefWidth(1100);
        vBox4.setPrefHeight(300);
        vBox4.setLayoutY(300);
        vBox4.setLayoutX(100);
        Label label16 = new Label("Lista e te gjitha Rezervimeve");label16.setId("label16");
        label16.setFont(Font.font(18));
        label16.setPadding(new Insets(20));

        TextField textField7 = new TextField();
        HBox.setMargin(textField7,new Insets(15));
        textField7.setPromptText("Kerko perdoruesin");
        textField7.getStyleClass().add("KerkoPerdoruesin");

        ComboBox<String> kolonat = new ComboBox<>();
        kolonat.getItems().addAll("Emri","Mbiemri","Qyteti","Shteti"
        ,"Mengjesi","Data_R","Data_S","Dhoma");

        HBox hBox6 = new HBox();
        Button Edit = new Button("Edit");
        HBox.setMargin(Edit,new Insets(15));
        Edit.getStyleClass().add("EditBtn");
        Button Delete = new Button("Delete");
        HBox.setMargin(Delete,new Insets(15,15,15,0));
        Delete.getStyleClass().add("DeleteBtn");

        HBox hBox7 = new HBox();
        hBox7.getChildren().addAll(label16,textField7,kolonat);

        hBox6.getChildren().addAll(Edit,Delete);
        BorderPane borderPane = new BorderPane();
        borderPane.setLeft(hBox7);
        borderPane.setRight(hBox6);

        TableView<Lista> tableView = new TableView<Lista>();
        tableView.setId("tableView");
        tableView.setPrefHeight(300);
        Label tableViewPlaceHolder = new Label("Nuk ka rezervime te reja");
        tableViewPlaceHolder.setStyle("-fx-text-fill:#302D40;");
        tableView.setPlaceholder(tableViewPlaceHolder);

        data = FXCollections.observableArrayList();

        /*TableColumn IDcol = new TableColumn("ID");
        IDcol.setPrefWidth(53);*/
        TableColumn EmriCol = new TableColumn("Emri");
        EmriCol.setPrefWidth(127);
        TableColumn mbiemriCol = new TableColumn("Mbiemri");
        mbiemriCol.setPrefWidth(130);
        TableColumn qytetiCol = new TableColumn("Qyteti");
        qytetiCol.setPrefWidth(130);
        TableColumn shteticol = new TableColumn("Shteti");
        shteticol.setPrefWidth(130);
        TableColumn DataRezervimitCol = new TableColumn("Data Rezervimit");
        DataRezervimitCol.setPrefWidth(130);
        TableColumn DataSkadimitCol = new TableColumn("Data Skadimit");
        DataSkadimitCol.setPrefWidth(130);
        TableColumn PerfshirjaMengjesitCol = new TableColumn("Perfshirja Mengjesit");
        PerfshirjaMengjesitCol.setPrefWidth(150);
        TableColumn DhomaCol = new TableColumn("Dhoma");
        DhomaCol.setPrefWidth(130);

       /* IDcol.setCellValueFactory(
                new PropertyValueFactory<Lista, Integer>("Idd"));*/
        EmriCol.setCellValueFactory(
                new PropertyValueFactory<Lista, String>("emrii"));
        mbiemriCol.setCellValueFactory(
                new PropertyValueFactory<Lista, String>("mbiemrii"));
        qytetiCol.setCellValueFactory(
                new PropertyValueFactory<Lista, String>("qytetii"));
        shteticol.setCellValueFactory(
                new PropertyValueFactory<Lista, String>("shtetii"));
        PerfshirjaMengjesitCol.setCellValueFactory(
                new PropertyValueFactory<Lista, String>("zgjedhja_mm"));
        DataRezervimitCol.setCellValueFactory(
                new PropertyValueFactory<Lista, String>("data_rr"));
        DataSkadimitCol.setCellValueFactory(
                new PropertyValueFactory<Lista, String>("data_ss"));
        DhomaCol.setCellValueFactory(
                new PropertyValueFactory<Lista, String>("Dhoma"));

        try{
            String SQL = "Select * from Home";
            ResultSet rs = con.createStatement().executeQuery(SQL);
            while(rs.next()){
                Lista cm = new Lista();
                cm.emrii.set(rs.getString("Emri"));
                cm.mbiemrii.set(rs.getString("Mbiemri"));
                cm.qytetii.set(rs.getString("Qyteti"));
                cm.shtetii.set(rs.getString("Shteti"));
                cm.zgjedhja_mm.set(rs.getString("Mengjesi"));
                cm.data_rr.set(rs.getString("Data_R"));
                cm.data_ss.set(rs.getString("Data_S"));
                cm.Dhoma.set(rs.getString("Dhoma"));
                data.add(cm);
            }
            tableView.setItems(data);
        }
        catch(Exception e){
            e.printStackTrace();
            System.out.println("Error te dhenat nuk jane paraqitur");
        }

        textField7.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent event) {

                String col = kolonat.getValue();

                if (event.getCode() == KeyCode.ENTER){
                    try{
                        String sql = "SELECT * FROM Home where Emri like \'"+textField7.getText()+"%\' or " +
                                "Mbiemri like \'"+textField7.getText()+"%\'";
                        String SQL = "select * from Home where "+col+" like \'"+textField7.getText()+"%\'";
                        ResultSet rs = con.createStatement().executeQuery(SQL);
                        tableView.getItems().clear();
                        while(rs.next()){
                            Lista cm = new Lista();
                            cm.emrii.set(rs.getString("Emri"));
                            cm.mbiemrii.set(rs.getString("Mbiemri"));
                            cm.qytetii.set(rs.getString("Qyteti"));
                            cm.shtetii.set(rs.getString("Shteti"));
                            cm.zgjedhja_mm.set(rs.getString("Mengjesi"));
                            cm.data_rr.set(rs.getString("Data_R"));
                            cm.data_ss.set(rs.getString("Data_S"));
                            cm.Dhoma.set(rs.getString("Dhoma"));
                            data.add(cm);
                        }
                        tableView.setItems(data);
                    }
                    catch(Exception e){
                        e.printStackTrace();
                        System.out.println("Error te dhenat nuk jane paraqitur");
                    }
                    if (textField7.getText().isEmpty()){
                        tableView.getItems().clear();
                        try{
                            String SQL = "Select * from Home";
                            ResultSet rs = con.createStatement().executeQuery(SQL);
                            while(rs.next()){
                                Lista cm = new Lista();
                                cm.emrii.set(rs.getString("Emri"));
                                cm.mbiemrii.set(rs.getString("Mbiemri"));
                                cm.qytetii.set(rs.getString("Qyteti"));
                                cm.shtetii.set(rs.getString("Shteti"));
                                cm.zgjedhja_mm.set(rs.getString("Mengjesi"));
                                cm.data_rr.set(rs.getString("Data_R"));
                                cm.data_ss.set(rs.getString("Data_S"));
                                cm.Dhoma.set(rs.getString("Dhoma"));
                                data.add(cm);
                            }
                            tableView.setItems(data);
                        }
                        catch(Exception e){
                            e.printStackTrace();
                            System.out.println("Error te dhenat nuk jane paraqitur");
                        }
                    }
                }
            }
        });

        Delete.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {

                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setHeaderText("A deshironi te fshini rreshtin");
                /*ButtonType buttonType = new ButtonType("OK");
                ButtonType buttonType1 = new ButtonType("Cancel");*/
                Optional<ButtonType> res = alert.showAndWait();
                Lista lista1 = tableView.getSelectionModel().getSelectedItem();
                String ii = lista1.getEmrii();
                if (res.get() == ButtonType.OK){
                    try {
                        String SQL = "delete from home where Emri = \'" + ii + "\'";
                        ResultSet rs = con.createStatement().executeQuery(SQL);
                    } catch (Exception e) {
                        e.printStackTrace();
                        System.out.println("Error te dhenat nuk jane paraqitur");
                    }
                    tableView.getItems().removeAll(tableView.getSelectionModel().getSelectedItem());
                }
                else if (res.get() == ButtonType.CANCEL) {
                    Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
                    alert1.setHeaderText("Veprimi per fshirje te te dhenes u anulua");
                    alert1.show();
                }
            }
        });

        Edit.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setHeaderText("A deshironi ta editoni rreshtin");
                /*ButtonType buttonType = new ButtonType("OK");
                ButtonType buttonType1 = new ButtonType("Cancel");*/
                Optional<ButtonType> res = alert.showAndWait();
                Lista lista1 = tableView.getSelectionModel().getSelectedItem();
                String ii = lista1.getEmrii();
                if (res.get() == ButtonType.OK) {
                    try {
                        String SQL = "insert into perNdryshim values (?)";
                        PreparedStatement ps = con.prepareStatement(SQL);
                        ps.setString(1,ii);
                        ps.executeUpdate();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    MenagjoDhenat menagjoDhenat = new MenagjoDhenat();
                    menagjoDhenat.start(stage);
                }
                else if (res.get() == ButtonType.CANCEL) {
                    Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
                    alert1.setHeaderText("Veprimi per editim te te dhenes u anulua");
                    alert1.show();
                }

            }
        });

        tableView.getColumns().addAll(EmriCol,mbiemriCol,qytetiCol,shteticol,DataRezervimitCol,DataSkadimitCol,
                PerfshirjaMengjesitCol,DhomaCol);
        VBox.setMargin(tableView,new Insets(0,20,0,20));

        vBox4.getChildren().addAll(borderPane,tableView);

        AnchorPane.setTopAnchor(hBox1,140.0);
        AnchorPane.setLeftAnchor(hBox1,100.0);

        Label label23 = new Label("Kthehu tek faqja kryesore");
        label23.getStyleClass().addAll("kthehu");
        label23.setStyle("-fx-text-fill: #86739B;");
        label23.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                home.start(stage);
            }
        });

        Button print = new Button("Print");

        print.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                try {
                    Printer printer = Printer.getDefaultPrinter(); //get the default printer
                    javafx.print.PageLayout pageLayout = printer.createPageLayout(Paper.NA_LETTER, PageOrientation.PORTRAIT, Printer.MarginType.DEFAULT); //create a pagelayout.  I used Paper.NA_LETTER for a standard 8.5 x 11 in page.
                    PrinterJob job = PrinterJob.createPrinterJob();//create a printer job

                    if (job.showPrintDialog(stage.getScene().getWindow()))// this is very useful it allows you to save the file as a pdf instead using all of your printer paper. A dialog box pops up, allowing you to change the "name" option from your default printer to Adobe pdf.
                    {
                        double pagePrintableWidth = pageLayout.getPrintableWidth(); //this should be 8.5 inches for this page layout.
                        double pagePrintableHeight = pageLayout.getPrintableHeight();// this should be 11 inches for this page layout.


                        tableView.prefHeightProperty().bind(Bindings.size(tableView.getItems()).multiply(35));// If your cells' rows are variable size you add the .multiply and play with the input value until your output is close to what you want. If your cells' rows are the same height, I think you can use .multiply(1). This changes the height of your tableView to show all rows in the table.
                        tableView.minHeightProperty().bind(tableView.prefHeightProperty());//You can probably play with this to see if it really needed.  Comment it out to find out.
                        tableView.maxHeightProperty().bind(tableView.prefHeightProperty());//You can probably play with this to see if it' really needed.  Comment it out to find out.

                        double scaleX = pagePrintableWidth / tableView.getBoundsInParent().getWidth();//scaling down so that the printing width fits within the paper width bound.
                        double scaleY = scaleX; //scaling the height using the same scale as the width. This allows the writing and the images to maintain their scale, or not look skewed.
                        double localScale = scaleX; //not really needed since everything is scaled down at the same ratio. scaleX is used thoughout the program to scale the print out.

                        double numberOfPages = Math.ceil((tableView.getPrefHeight() * localScale) / pagePrintableHeight);//used to figure out the number of pages that will be printed.


                        tableView.getTransforms().add(new Scale(scaleX, (scaleY)));//scales the printing. Allowing the width to say within the papers width, and scales the height to do away with skewed letters and images.
                        tableView.getTransforms().add(new Translate(0, 0));// starts the first print at the top left corner of the image that needs to be printed

                        //Since the height of what needs to be printed is longer than the paper heights we use gridTransfrom to only select the part to be printed for a given page.
                        Translate gridTransform = new Translate();
                        tableView.getTransforms().add(gridTransform);

                        //now we loop though the image that needs to be printed and we only print a subimage of the full image.
                        //for example: In the first loop we only pint the printable image from the top down to the height of a standard piece of paper. Then we print starting from were the last printed page ended down to the height of the next page. This happens until all of the pages are printed.
                        // first page prints from 0 height to -11 inches height, Second page prints from -11 inches height to -22 inches height, etc.
                        for (int i = 0; i < numberOfPages; i++) {
                            gridTransform.setY(-i * (pagePrintableHeight / localScale));
                            job.printPage(pageLayout, tableView);
                        }

                        job.endJob();
                    }
                }
                catch (Exception e){
                    e.printStackTrace();
                }
            }
        });

        print.getStyleClass().addAll("EditBtn");
        BorderPane borderPane1 = new BorderPane();
        borderPane1.setLeft(label23);
        borderPane1.setRight(print);
        borderPane1.setPrefWidth(1100);
        AnchorPane.setLeftAnchor(borderPane1,100.0);
        AnchorPane.setTopAnchor(borderPane1,650.0);
//        AnchorPane.setLeftAnchor(label23,100.0);
        VBox.setMargin(label23,new Insets(20,0,0,100));

        anchorPane.getChildren().addAll(hBox,hBox1,vBox4,borderPane1);
        g.getChildren().add(anchorPane);
        scene.getStylesheets().addAll("style.css","style3.css");
        stage.setTitle("Lista e Rezervimeve");
        stage.setScene(scene);
        stage.show();
    }
}
