package projekt;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class LogIn extends Application {

    private Connection con;
    private Statement st;
    private ResultSet rs;

    public LogIn() {
        try{
            String connectionUrl = "jdbc:sqlserver://localhost:1433;" +
                    "databaseName=LendeLaboratorike;user=sa;password=arlind11;";
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            con = DriverManager.getConnection(connectionUrl);
            st = con.createStatement();
            System.out.println("Connected");
        }
        catch (Exception err)
        {
            System.err.println("Error loading JDBC driver");
            err.printStackTrace(System.err);
            System.exit(0);
        }
    }

    public static void main(String[] args) {
        launch(args);
    }

    String username;
    int password;
    String SQLusername;
    int SQLpassword;
    byte pass[] = new byte[50];

    public byte[] getPass() {
        return pass;
    }

    public void setPass(byte[] pass) {
        this.pass = pass;
    }

    public String getSQLusername() {
        return SQLusername;
    }

    public void setSQLusername(String SQLusername) {
        this.SQLusername = SQLusername;
    }

    public int getSQLpassword() {
        return SQLpassword;
    }

    public void setSQLpassword(int SQLpassword) {
        this.SQLpassword = SQLpassword;
    }

    @Override
    public void start(Stage stage) {
        ScrollPane scrollPane = new ScrollPane();
        GridPane gridPane = new GridPane();
        gridPane.setStyle("-fx-background-color:#363348;");
        scrollPane.setContent(gridPane);
        VBox vBox = new VBox();vBox.setId("pane");
        Scene scene = new Scene(scrollPane,1400,800);
        gridPane.setPrefHeight(scene.getHeight());
        gridPane.setPrefWidth(scene.getWidth());
        vBox.setPrefWidth(400);
        vBox.setPrefHeight(450);

        Label label = new Label("Shenoni te dhenat dhe kycu ne llogarine tuaj");
        label.setId("label");
        label.setWrapText(true);

        Label label1 = new Label("Email");
        label1.setId("label1");

        TextField textField = new TextField();
        textField.setId("Emailtxf1");
        textField.setPromptText("Username");
        VBox.setMargin(textField,new Insets(0,20,0,20));
        username = textField.getText();

        Label label2 = new Label("Password");
        label2.setId("label2");

        PasswordField passwordField = new PasswordField();
        passwordField.setId("passwordtxf2");
        passwordField.setPromptText("Password");
        VBox.setMargin(passwordField,new Insets(0,20,20,20));
//        password = Integer.parseInt(passwordField.getText());

        Button button = new Button("Kyqu ne llogari");
        button.setId("buton");
        button.getStyleClass().add("a11");
        VBox.setMargin(button,new Insets(20,20,15,20));
        button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                home home = new home();
                try {
                    String sql = "select Username,Password from Adminat where Username ="+"\'"+textField.getText()
                            +"\' and Password =convert (binary,"+passwordField.getText()+")";
                    rs = st.executeQuery(sql);
                    while (rs.next()){
                        setSQLusername(rs.getString("Username"));
                        setPass(rs.getBytes("Password"));
                    }
                }catch (Exception e){
                    e.getStackTrace();
                }
                if (textField.getText().isEmpty()){
                    alerti("Username-i");
                }
                else if (passwordField.getText().isEmpty()){
                    alerti("Password-i");
                }
                else if(getSQLusername() != null && getPass() != null){

                    home.start(stage);
                }
            }
        });
        ComboBox<String> privat = new ComboBox<>();
        privat.getItems().addAll("hin msheft");
        button.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if (event.getButton() == MouseButton.SECONDARY){
                    vBox.getChildren().add(privat);
                    privat.setOnAction(new EventHandler<ActionEvent>() {
                        @Override
                        public void handle(ActionEvent event) {
                            if (privat.getValue().equals("hin msheft")){
                                home home = new home();
                                home.start(stage);
                            }

                        }
                    });
                }
            }
        });
        scene.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if (event.getButton() == MouseButton.PRIMARY){
                    vBox.getChildren().remove(privat);
                }
            }
        });
        textField.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent event) {

                home home = new home();
                if (event.getCode().equals(KeyCode.ENTER)) {
                    try {
                        String sql = "select Username,Password from Adminat where Username ="+"\'"+textField.getText()
                                +"\' and Password =convert (binary,"+passwordField.getText()+")";
                        rs = st.executeQuery(sql);
                        while (rs.next()){
                            setSQLusername(rs.getString("Username"));
                            setPass(rs.getBytes("Password"));
                        }
                    }catch (Exception e){
                        e.getStackTrace();
                    }
                    if (textField.getText().isEmpty()){
                        alerti("Username-i");
                    }
                    else if (passwordField.getText().isEmpty()){
                        alerti("Password-i");
                    }
                    else if(getSQLusername() != null && getPass() != null){

                        home.start(stage);
                    }
                }
            }
        });
        passwordField.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent event) {
                home home = new home();
                if (event.getCode().equals(KeyCode.ENTER)) {
                    try {
                        String sql = "select Username,Password from Adminat where Username ="+"\'"+textField.getText()
                                +"\' and Password =convert (binary,"+passwordField.getText()+")";
                        rs = st.executeQuery(sql);
                        while (rs.next()){
                            setSQLusername(rs.getString("Username"));
                            setPass(rs.getBytes("Password"));
                        }
                    }catch (Exception e){
                        e.getStackTrace();
                    }
                    if (textField.getText().isEmpty()){
                        alerti("Username-i");
                    }
                    else if (passwordField.getText().isEmpty()){
                        alerti("Password-i");
                    }
                    else if(getSQLusername() != null && getPass() != null){

                        home.start(stage);
                    }
                }
            }
        });

        vBox.getChildren().addAll(label,label1,textField,label2,passwordField,button);

        GridPane.setMargin(vBox,new Insets(150,0,0,500));
        gridPane.getChildren().add(vBox);
        scene.getStylesheets().add("style1.css");
        stage.setTitle("Log In");
        stage.setScene(scene);
        stage.show();
    }
    void alerti(String Header){
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setHeaderText(Header+" juaj duhet te shenohet");
        alert.setContentText("Ju lutem rishikojini te dhenat");
        alert.show();
    }
}
