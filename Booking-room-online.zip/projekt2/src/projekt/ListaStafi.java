
package projekt;
import javafx.beans.property.SimpleStringProperty;

public class ListaStafi {

    public SimpleStringProperty emrii = new SimpleStringProperty();
    public SimpleStringProperty mbiemrii = new SimpleStringProperty();
    public SimpleStringProperty qytetii = new SimpleStringProperty();
    public SimpleStringProperty roli = new SimpleStringProperty();
    public SimpleStringProperty fillimiPunes = new SimpleStringProperty();
    public SimpleStringProperty pagaMujore = new SimpleStringProperty();

    public String getEmrii() {
        return emrii.get();
    }

    public void setEmrii(String emri) {
        this.emrii = new SimpleStringProperty(emri);
    }


    public String getMbiemrii() {
        return mbiemrii.get();
    }

    public void setMbiemrii(String mbiemri) {
        this.mbiemrii = new SimpleStringProperty(mbiemri);
    }

    public String getQytetii() {
        return qytetii.get();
    }

    public void setQytetii(String qyteti) {
        this.qytetii = new SimpleStringProperty(qyteti);
    }

    public String getRoli() {
        return roli.get();
    }

    public void setRoli(String roli) {
        this.roli = new SimpleStringProperty(roli);
    }

    public String getFillimiPunes() {
        return fillimiPunes.get();
    }

    public void setZgjedhja_mm(String fillimiPunes) {
        this.fillimiPunes = new SimpleStringProperty(fillimiPunes);
    }

    public String getPagaMujore() {
        return pagaMujore.get();
    }

    public void setPagaMujore(String pagaMujore) {
        this.pagaMujore = new SimpleStringProperty(pagaMujore);
    }
}