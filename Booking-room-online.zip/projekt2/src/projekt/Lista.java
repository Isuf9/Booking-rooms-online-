
package projekt;
import javafx.beans.property.SimpleStringProperty;

public class Lista {

    public SimpleStringProperty emrii = new SimpleStringProperty();
    public SimpleStringProperty mbiemrii = new SimpleStringProperty();
    public SimpleStringProperty qytetii = new SimpleStringProperty();
    public SimpleStringProperty shtetii = new SimpleStringProperty();
    public SimpleStringProperty zgjedhja_mm = new SimpleStringProperty();
    public SimpleStringProperty data_rr = new SimpleStringProperty();
    public SimpleStringProperty data_ss = new SimpleStringProperty();
    public SimpleStringProperty Dhoma = new SimpleStringProperty();

    public String getEmrii() {
        return emrii.get();}
    public  void  setEmrii(String emri) {
        this.emrii=new SimpleStringProperty(emri);}


    public String getMbiemrii() {
        return mbiemrii.get();}
    public  void  setMbiemrii(String mbiemri) {
        this.mbiemrii=new SimpleStringProperty(mbiemri);}

    public String getQytetii() {
        return qytetii.get();}
    public  void  setQytetii(String qyteti) {
        this.qytetii=new SimpleStringProperty(qyteti);}

    public String getShtetii() {
        return shtetii.get();}
    public  void  setShtetii(String shteti) {
        this.shtetii=new SimpleStringProperty(shteti);}

    public String getZgjedhja_mm() {
        return zgjedhja_mm.get();}
    public  void  setZgjedhja_mm(String zgjedhja_m) {
        this.zgjedhja_mm=new SimpleStringProperty(zgjedhja_m);}

    public String getData_rr() {
        return data_rr.get();}
    public  void  setData_rr(String data_r) {
        this.data_rr=new SimpleStringProperty(data_r);}

    public String getData_ss() {
        return data_ss.get();}
    public  void  setData_ss(String data_s) {
        this.data_ss=new SimpleStringProperty(data_s);}

    public String getDhoma() {
        return Dhoma.get();
    }

    public SimpleStringProperty dhomaProperty() {
        return Dhoma;
    }

    public void setDhoma(String dhoma) {
        this.Dhoma.set(dhoma);
    }
}
